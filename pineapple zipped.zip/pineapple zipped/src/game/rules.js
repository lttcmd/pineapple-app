import rules from "../../rules.json" assert { type: "json" };
export default rules;
