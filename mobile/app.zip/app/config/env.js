export const SERVER_URL = "http://192.168.1.78:3000";
// The Socket.IO endpoint will use the same origin.
// RN connects as: io(SERVER_URL, { auth: { token } })
