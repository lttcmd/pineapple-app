import React, { useState } from "react";
import { View, Text, TextInput, Button, Alert } from "react-native";
import axios from "axios";
import * as SecureStore from "expo-secure-store";
import { SERVER_URL } from "../config/env";

export default function AuthPhone({ navigation }) {
  const [phone, setPhone] = useState("");

  async function sendCode() {
    try {
      const p = phone.trim();
      if (!p) return;
      await axios.post(`${SERVER_URL}/auth/send-otp`, { phone: p });
      await SecureStore.setItemAsync("ofc_phone", p);
      navigation.navigate("AuthCode");
    } catch (e) {
      Alert.alert("Error", "Could not send code.");
    }
  }

  return (
    <View style={{ padding:16, gap:12 }}>
      <Text style={{ fontSize:18, fontWeight:"600" }}>Enter phone number</Text>
      <TextInput
        value={phone}
        onChangeText={setPhone}
        placeholder="+61 4xx xxx xxx"
        autoCapitalize="none"
        keyboardType="phone-pad"
        style={{ borderWidth:1, borderRadius:8, padding:12 }}
      />
      <Button title="Send code" onPress={sendCode} />
    </View>
  );
}
