import React, { useEffect, useState } from "react";
import { View, Text, TextInput, Button } from "react-native";
import { connectSocket, onSocketEvent, emit } from "../net/socket";
import { useGame } from "../state/useGame";
import { colors } from "../theme/colors";
import Panel from "../components/Panel";

export default function Lobby({ navigation }) {
  const [room, setRoom] = useState("");
  const [name, setName] = useState("");
  const applyEvent = useGame(s => s.applyEvent);
  const setNameInStore = useGame(s => s.setName);

  useEffect(() => {
    let off = () => {};
    (async () => {
      try {
        await connectSocket();
        off = onSocketEvent((evt, data) => {
          if (evt === "room:create" && data?.roomId) {
            setRoom(data.roomId);
            emit("room:join", { roomId: data.roomId, name: name || "Player" });
          }
          applyEvent(evt, data);
        });
      } catch {
        navigation.replace("AuthPhone");
      }
    })();
    return () => off();
  }, [name]);

  return (
    <View style={{ flex:1, backgroundColor: colors.bg, padding:16, gap:12 }}>
      <Text style={{ color: colors.text, fontSize:22, fontWeight:"800", marginBottom: 8 }}>Pineapple OFC</Text>

      <Panel style={{ gap:10 }}>
        <Text style={{ color: colors.sub }}>Name</Text>
        <TextInput
          value={name}
          onChangeText={(t)=>{ setName(t); setNameInStore(t); }}
          placeholder="Your name"
          placeholderTextColor="#9aa4bf"
          style={{ borderWidth:1, borderColor: colors.outline, borderRadius:10, padding:12, color: colors.text, backgroundColor: colors.panel2 }}
        />
        <Button title="Create Room" onPress={() => emit("room:create")} />
      </Panel>

      <Panel style={{ gap:10 }}>
        <Text style={{ color: colors.sub }}>Room Code</Text>
        <TextInput
          value={room}
          onChangeText={setRoom}
          placeholder="e.g. ABC123"
          placeholderTextColor="#9aa4bf"
          autoCapitalize="characters"
          style={{ borderWidth:1, borderColor: colors.outline, borderRadius:10, padding:12, color: colors.text, backgroundColor: colors.panel2 }}
        />
        <Button
          title="Join Room"
          onPress={() => {
            const code = room.trim();
            if (!code) return;
            emit("room:join", { roomId: code, name: name || "Player" });
            navigation.navigate("Room", { roomId: code });
          }}
        />
      </Panel>
    </View>
  );
}
