import React, { useEffect, useMemo, useRef, useState } from "react";
import { View, Text, Button, FlatList, findNodeHandle, UIManager } from "react-native";
import * as Haptics from "expo-haptics";
import { onSocketEvent, emit } from "../net/socket";
import { useGame } from "../state/useGame";
import { colors } from "../theme/colors";
import Card from "../components/Card";
import DraggableCard from "../components/DraggableCard";
import { useDrag } from "../drag/DragContext";

const SLOT_W = 48;
const SLOT_H = 68;
const SLOT_GAP = 10;

function Row({
  label,
  capacity,
  committed,
  staged,
  zoneRef,
  highlightRow,
  onMove,
  onDrop,
  onLayout,
}) {
  const committedCount = committed.length;
  const stagedCount = staged.length;
  const remaining = Math.max(0, capacity - committedCount - stagedCount);

  return (
    <View style={{ marginBottom: 12 }} pointerEvents="box-none">
      <Text style={{ color: colors.sub, marginBottom: 6 }}>{label}</Text>
      <View
        ref={zoneRef}
        onLayout={onLayout}
        pointerEvents="box-none"
        style={{
          flexDirection: "row",
          alignItems: "center",
          paddingVertical: 6,
          borderRadius: 12,
          borderWidth: highlightRow ? 2 : 0,
          borderColor: highlightRow ? colors.accent : "transparent",
        }}
      >
        {committed.map((c, i) => (
          <View key={"c_"+label+i} style={{ marginRight: SLOT_GAP }} pointerEvents="none">
            <Card card={c} small />
          </View>
        ))}
        {staged.map((c, i) => (
          <View key={"s_"+label+i} style={{ marginRight: SLOT_GAP }} pointerEvents="box-none">
            <DraggableCard card={c} small onMove={onMove} onDrop={onDrop} />
          </View>
        ))}
        {Array.from({ length: remaining }).map((_, i) => (
          <View
            key={"p_"+label+i}
            style={{
              width: SLOT_W,
              height: SLOT_H,
              marginRight: SLOT_GAP,
              borderWidth: 2,
              borderColor: highlightRow ? colors.accent : colors.outline,
              borderRadius: 10,
              backgroundColor: "rgba(255,255,255,0.05)",
            }}
            pointerEvents="none"
          />
        ))}
      </View>
    </View>
  );
}

export default function Play({ route }) {
  const { roomId } = route.params || {};
  const {
    board,
    hand,
    staged,
    turnCap,
    canCommit,
    applyEvent,
    setPlacement,
    unstage,
    commitTurnLocal,
  } = useGame();

  const { drag } = useDrag();

  // measure rows for hover/drop
  const topRef = useRef(null), midRef = useRef(null), botRef = useRef(null);
  const [zones, setZones] = useState({ top: null, middle: null, bottom: null });
  const [hover, setHover] = useState(null); // 'top' | 'middle' | 'bottom' | null

  function measure(ref, key) {
    const node = findNodeHandle(ref.current);
    if (!node) return;
    UIManager.measureInWindow(node, (x, y, width, height) =>
      setZones((z) => ({ ...z, [key]: { x, y, width, height } }))
    );
  }
  const onTopLayout = () => measure(topRef, "top");
  const onMidLayout = () => measure(midRef, "middle");
  const onBotLayout = () => measure(botRef, "bottom");

  useEffect(() => {
    const off = onSocketEvent((evt, data) => applyEvent(evt, data));
    return () => off();
  }, [applyEvent]);

  useEffect(() => {
    const t = setTimeout(() => {
      measure(topRef, "top");
      measure(midRef, "middle");
      measure(botRef, "bottom");
    }, 0);
    return () => clearTimeout(t);
  }, []);

  // split staged by row
  const stagedTop    = useMemo(() => staged.placements.filter(p => p.row === "top").map(p => p.card), [staged]);
  const stagedMiddle = useMemo(() => staged.placements.filter(p => p.row === "middle").map(p => p.card), [staged]);
  const stagedBottom = useMemo(() => staged.placements.filter(p => p.row === "bottom").map(p => p.card), [staged]);

  // cards available: exclude committed + staged + discard
  const visibleHand = useMemo(() => {
    const taken = new Set([
      ...board.top, ...board.middle, ...board.bottom,
      ...staged.placements.map(p => p.card),
    ]);
    if (staged.discard) taken.add(staged.discard);
    return hand.filter(c => !taken.has(c));
  }, [hand, board, staged]);

  // hit-test helpers
  function inRect(r, x, y, pad = 36) {
    if (!r) return false;
    return x >= r.x - pad && x <= r.x + r.width + pad && y >= r.y - pad && y <= r.y + r.height + pad;
  }
  function zoneAt(x, y) {
    if (inRect(zones.top, x, y)) return "top";
    if (inRect(zones.middle, x, y)) return "middle";
    if (inRect(zones.bottom, x, y)) return "bottom";
    return null;
  }

  const onMove = ({ x, y }) => {
    if (!zones.top || !zones.middle || !zones.bottom) {
      measure(topRef, "top"); measure(midRef, "middle"); measure(botRef, "bottom");
    }
    setHover(zoneAt(x, y));
  };

  const onDrop = ({ card, pageX, pageY }) => {
    const z = zoneAt(pageX, pageY) || hover;
    setHover(null);
    if (z === "top")    { setPlacement("top", card); Haptics.selectionAsync(); return; }
    if (z === "middle") { setPlacement("middle", card); Haptics.selectionAsync(); return; }
    if (z === "bottom") { setPlacement("bottom", card); Haptics.selectionAsync(); return; }
    return unstage(card);
  };

  const onCommit = () => {
    if (!canCommit()) return;
    emit("action:ready", { roomId, placements: staged.placements });
    commitTurnLocal();
  };

  const needed = turnCap();
  const stagedCount = staged.placements.length;
  const canPress = stagedCount === needed;
  const headerText = committedTotal(board) === 0 ? "Place 5" : "Place 2";

  return (
    <View style={{ flex: 1, backgroundColor: colors.bg, padding: 16 }} pointerEvents="box-none">
      <Text style={{ color: colors.text, fontWeight: "800", marginBottom: 8 }}>
        Room: {roomId} • {headerText}
      </Text>

      <Row
        label="Top (3)"
        capacity={3}
        committed={board.top}
        staged={stagedTop}
        zoneRef={topRef}
        highlightRow={hover === "top"}
        onMove={onMove}
        onDrop={onDrop}
        onLayout={onTopLayout}
      />
      <Row
        label="Middle (5)"
        capacity={5}
        committed={board.middle}
        staged={stagedMiddle}
        zoneRef={midRef}
        highlightRow={hover === "middle"}
        onMove={onMove}
        onDrop={onDrop}
        onLayout={onMidLayout}
      />
      <Row
        label="Bottom (5)"
        capacity={5}
        committed={board.bottom}
        staged={stagedBottom}
        zoneRef={botRef}
        highlightRow={hover === "bottom"}
        onMove={onMove}
        onDrop={onDrop}
        onLayout={onBotLayout}
      />

      {/* Discard (display-only; set after trio commits) */}
      <View style={{ marginTop: 6, marginBottom: 12 }}>
        <Text style={{ color: colors.sub, marginBottom: 6 }}>Discard</Text>
        <View style={{ minHeight: SLOT_H, flexDirection: "row", alignItems: "center" }}>
          {staged.discard ? <Card card={staged.discard} small /> : <Text style={{ color: colors.sub }}>(auto after commit)</Text>}
        </View>
      </View>

      {/* Hand */}
      <View style={{ flex: 1 }}>
        <Text style={{ color: colors.sub, marginBottom: 8 }}>
          Your Hand • {stagedCount}/{needed}
        </Text>
        <FlatList
          data={visibleHand}
          horizontal
          scrollEnabled={false}
          keyExtractor={(c, i) => c + ":" + i}
          renderItem={({ item }) => (
            <View style={{ marginRight: SLOT_GAP }} pointerEvents="box-none">
              <DraggableCard card={item} onMove={onMove} onDrop={onDrop} />
            </View>
          )}
        />
      </View>

      {/* Actions */}
      <View style={{ flexDirection: "row", gap: 10, marginTop: 12 }}>
        <View style={{ flex: 1 }}>
          <Button title="Clear staged" onPress={() => useGame.getState().clearStage()} />
        </View>
        <View style={{ flex: 1, opacity: canPress ? 1 : 0.5 }}>
          <Button title="Ready (commit)" onPress={onCommit} disabled={!canPress} />
        </View>
      </View>
    </View>
  );
}

// local helper used in header
function committedTotal(board) {
  return board.top.length + board.middle.length + board.bottom.length;
}
