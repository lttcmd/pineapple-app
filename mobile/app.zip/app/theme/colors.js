export const colors = {
  bg: "#0B132B",
  panel: "#1C2541",
  panel2: "#2E3A66",
  text: "#EAEAEA",
  sub: "#A7B1C6",
  accent: "#5BC0BE",
  outline: "#3A476B",
  danger: "#FF6B6B",
  ok: "#19D3AE",
  cardFace: "#F7F7F7",
};
