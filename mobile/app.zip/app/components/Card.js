import React from "react";
import { Pressable, View, Text } from "react-native";
import { colors } from "../theme/colors";

const SUIT = { s: "♠", h: "♥", d: "♦", c: "♣" };

function parse(card) {
  if (!card) return { rank: "?", suit: "?" };
  const rank = card.slice(0, -1);
  const suit = card.slice(-1).toLowerCase();
  return { rank, suit, sym: SUIT[suit] || "?" };
}

function Face({ card, selected, small }) {
  const { rank, sym, suit } = parse(card);
  const red = suit === "h" || suit === "d";
  const w = small ? 48 : 64;
  const h = small ? 68 : 88;

  return (
    <View
      style={{
        width: w, height: h, borderRadius: 10, borderWidth: 2,
        borderColor: selected ? colors.accent : colors.outline,
        backgroundColor: colors.cardFace,
        justifyContent: "space-between", padding: 6,
        shadowColor: "#000", shadowOpacity: 0.15, shadowRadius: 6, shadowOffset: { width: 0, height: 3 },
        elevation: 3
      }}
    >
      <Text style={{ fontWeight: "700", fontSize: small ? 14 : 16, color: red ? "#C62828" : "#111" }}>{rank}</Text>
      <Text style={{ alignSelf: "flex-end", fontSize: small ? 16 : 20, color: red ? "#C62828" : "#111" }}>{sym}</Text>
    </View>
  );
}

export default function Card({ card, selected, onPress, small=false }) {
  if (onPress) {
    return (
      <Pressable onPress={onPress} style={{ marginRight: 10 }}>
        <Face card={card} selected={selected} small={small} />
      </Pressable>
    );
  }
  return (
    <View style={{ marginRight: 10 }}>
      <Face card={card} selected={selected} small={small} />
    </View>
  );
}
