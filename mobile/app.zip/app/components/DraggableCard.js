import React, { useState } from "react";
import { View } from "react-native";
import {
  Gesture,
  GestureDetector,
} from "react-native-gesture-handler";
import Animated, { runOnJS } from "react-native-reanimated";
import Card from "./Card";
import { useDrag } from "../drag/DragContext";

/**
 * DraggableCard (Gesture API)
 * - Lifts the real card into the global overlay via DragContext (no duplicates).
 * - Calls onMove({x,y}) during drag for hover highlighting.
 * - Calls onDrop({ card, pageX, pageY }) on release for snapping.
 */
export default function DraggableCard({ card, small = false, onMove, onDrop }) {
  const { begin, move, end } = useDrag();
  const [dragging, setDragging] = useState(false);

  const pan = Gesture.Pan()
    .hitSlop({ horizontal: 8, vertical: 8 }) // easier to grab
    .onBegin((evt) => {
      runOnJS(setDragging)(true);
      runOnJS(begin)({
        card,
        small,
        x: evt.absoluteX,
        y: evt.absoluteY,
        offsetX: evt.x,
        offsetY: evt.y,
      });
      if (onMove) runOnJS(onMove)({ x: evt.absoluteX, y: evt.absoluteY });
    })
    .onUpdate((evt) => {
      runOnJS(move)(evt.absoluteX, evt.absoluteY);
      if (onMove) runOnJS(onMove)({ x: evt.absoluteX, y: evt.absoluteY });
    })
    .onEnd((evt) => {
      runOnJS(end)();
      runOnJS(setDragging)(false);
      if (onDrop) runOnJS(onDrop)({ card, pageX: evt.absoluteX, pageY: evt.absoluteY });
    })
    .onFinalize(() => {
      // covers cancel/interrupt
      runOnJS(end)();
      runOnJS(setDragging)(false);
    });

  return (
    <GestureDetector gesture={pan}>
      <Animated.View>
        {/* While dragging, the element lives in the overlay; leave a fixed-size placeholder */}
        {dragging ? (
          <View style={{ width: 48, height: 68 }} />
        ) : (
          <Card card={card} small={small} />
        )}
      </Animated.View>
    </GestureDetector>
  );
}
